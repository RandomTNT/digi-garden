items = [{"tag": "Axe", "texture": "axe", "type": "tool", "id": 1, "stats": {"str": 3}, "interact_w": [2], "qty": -1},
         {"tag": "Pickaxe", "texture": "pickaxe", "type": "tool", "id": 4, "stats": {"str": 5}, "interact_w": [5], "qty": -1}]
resources = [{"tag": "Log", "texture": "log", "type": "resource", "id": 3, "qty": 1},
             {"tag": "Cobblestone", "texture": "cobblestone", "type": "resource", "id": 6, "qty": 1}]
location_objects = [{"tag": "Tree", "texture": "tree", "id": 2, "resources": [0], "hp": 15, "max_hp": 15, "qty": -1},
                    {"tag": "Stone", "texture": "stone", "id": 5, "resources": [1], "hp": 25, "max_hp": 25, "qty": -1}]
seeds = [{"tag": "Magic flower", "texture": "magic_flower", "type": "seed", "plant": [8], "id": 7, "qty": 1}]
plants = []
nickname_filter = "0123456789abcdefghijklmnopqrstuvwxyz_абвгдеёжзийклмнопрстуфхцчшщъыьэюя "
cases = [{"name": "random resource", "cost": 500, "drop": "resources"}]