import random

from flask import Flask, request, render_template, jsonify
import random
import sqlite3
import json
import hashlib
import game
import traceback
import time as _time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
app = Flask(__name__)


#smtp_server = smtplib.SMTP("smtp.mail.ru", 465)
#smtp_server.starttls()
#smtp_server.login("cardvival@xmail.ru", "Rg5mApNUpdtC4VuGavZs")

latest_version = "1fx23"
latest_version_link = ""

@app.route("/")
def root():
    return render_template("index.html")


@app.route("/api")
def api():
    return render_template("lol.html")


@app.route("/api/ping")
def ping():
    return "pong!"

@app.route("/api/chat")
def chat():
    token = request.args["token"]
    action = request.args["action"]
    user_id = request.args["user_id"]
    action_content = request.args["ac"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        chat_id = f"{user_to_dict(user)["id"]}-{user_id}"
        try:
            cursor.execute("SELECT * FROM chats WHERE id = ?", (chat_id,))
            chat = cursor.fetchone()
        except:
            chat = None
        cursor.execute("SELECT * FROM users WHERE id = ?", (int(user_id),))
        friend = cursor.fetchone()
        if friend or chat:
            messages = json.loads(chat[1]) if chat else []
            match action:
                case "send":
                    if not messages:
                        cursor.execute("INSERT INTO Chat (id, messages) VALUES (?, ?)", (chat_id, json.dumps([]),))
                        connection.commit()
                    messages.append({"player_id": user_to_dict(user)["id"], "message": action_content})
                    cursor.execute("UPDATE chats SET messages = ? WHERE id = ?", (messages, chat_id,))
                    connection.commit()
                    connection.close()
                    return {"action": action, "messages": messages}
                case "read":
                    return {"action": action, "messages": messages}




@app.route("/api/friends/add")
def add_friend():
    token = request.args["token"]
    player_id = int(request.args["player_id"])
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        friends = user_to_dict(user)["friends"]
        cursor.execute("SELECT * FROM users WHERE id = ?", (player_id,))
        friend = cursor.fetchone()
        if friend:
            is_friend = None
            if not player_id in friends:
                friends.append(player_id)
                is_friend = True
            else:
                friends.remove(player_id)
                is_friend = False
            cursor.execute("UPDATE Users SET friends = ? WHERE token = ?", (json.dumps(friends), token,))
            connection.commit()
            connection.close()
            return {"friends": friends, "is_friend": is_friend}
        else:
            return {"error": "your new friend not found"}
    else:
        return {"error": "user not found"}

@app.route("/api/case/open")
def open_case():
    token = request.args["token"]
    case = game.cases[int(request.args["case"])]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        wallet = json.loads(user[8])
        if wallet["gold"] >= case["cost"]:
            wallet["gold"] -= case["cost"]
            item = random.choice(game.resources)
            qty = random.randrange(0, 500)
            item["qty"] = qty
            inventory = add_to_inventory(user_to_dict(user)["inventory"], item)
            cursor.execute("UPDATE Users SET wallet = ?, inventory = ? WHERE token = ?", (json.dumps(wallet), json.dumps(inventory), token,))
            connection.commit()
            connection.close()
            return {"item": item, "qty": qty, "wallet": {"gold": format(wallet["gold"], ",").replace(",", " ")}, "inventory": inventory}
        else:
            connection.close()
            return {"error": "Недостаточно монет для покупки"}
    else:
        connection.close()
        return {"error": "user not found"}
        


@app.route("/api/friends")
def friends_list():
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        friends = user_to_dict(user)["friends"]
        friends_list = []
        for friend in friends:
            try:
                cursor.execute("SELECT * FROM users WHERE id = ?", (friend,))
                friend_module = cursor.fetchone()
                friends_list.append(safe_user_to_dict(friend_module))
            except:
                print("ошибка я покакал")
        print(friends_list)
        return {"friends": friends_list, "friends_ids": friends}
    else:
        {"error": "unknown user"}

@app.route("/api/search_players")
def search_players():
    nickname = f'%{request.args["nickname"]}%'
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT * FROM users WHERE nickname like ?", (nickname,))
        players = cursor.fetchall()
        players_list = []
        for player in players:
            players_list.append(safe_user_to_dict(player))
        return {"players": players_list}
    else:
        return {"error": "user not found"}

@app.route("/api/sleep")
def sleep():
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user and user_to_dict(user)["status"]["type"] != "sleeping":
        user = user_to_dict(user)
        if user["stats"]["energy"] >= 300:
            return {"error": "ты чувствуешь себя бодрым.\nсмысла ложиться спать нет."}
        cursor.execute("UPDATE Users SET status = ? WHERE token = ?", ((json.dumps({"type": "sleeping", "timer": _time.time() + 59})), token,))
        connection.commit()
        connection.close()
        return json.dumps({"type": user["status"]["type"], "timer": _time.time() + 60})
    elif user and (user_to_dict(user)["status"]["type"] == "sleeping") and (_time.time() - user_to_dict(user)["status"]["timer"] >= 0):
        stats = user_to_dict(user)["stats"]
        stats["energy"] = 300
        cursor.execute("UPDATE Users SET status = ?, stats = ? WHERE token = ?", ((json.dumps({"type": "cheerful", "timer": 0})), json.dumps(stats), token,))
        connection.commit()
        connection.close()
        return {"t": "rue"}
    elif user and (user_to_dict(user)["status"]["type"] == "sleeping"):
        cursor.execute("UPDATE Users SET status = ? WHERE token = ?", ((json.dumps({"type": "cheerful", "timer": 0})), token,))
        connection.commit()
        connection.close()
        return {"t": "rue"}
    else:
        connection.close()
        return {"error": "user not found"}


@app.route("/api/check_update")
def check_update():
    current_version = request.args["current_version"]
    if current_version != latest_version:
        if current_version.startswith("dev-"):
            return {"status": "dev_build", "dl_link": "ヾ(≧ ▽ ≦)ゝ"}
        else:
            return {"status": "old", "dl_link": latest_version_link}
    else:
        return {"status": "latest"}


@app.route("/api/user/<int:user_id>", methods=["GET"])
def user_info(user_id):
    return not_avaliable()
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    connection.close()
    if user:
        return jsonify(user), 200
    else:
        return jsonify({"error": "User not found!"}), 404


@app.route("/api/market/buy")
def buy_item():
    item = request.args["item"]
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT * FROM Market WHERE id = ?", (item,))
        item = cursor.fetchone()
        if item:
            if user:
                if json.loads(user[8])["gold"] >= json.loads(item[2]):
                    gold = json.loads(user[8])["gold"] - json.loads(item[2])
                    cursor.execute("UPDATE Users SET wallet = ? WHERE token = ?", (json.dumps({"gold": gold}), token))
                    inventory = user_to_dict(user)["inventory"]
                    inventory = add_to_inventory(inventory, item[0])
                    cursor.execute("UPDATE Users SET inventory = ? WHERE token = ?", (json.dumps(inventory), token))
                    connection.commit()
                    connection.close()
                else:
                    connection.close()
                    return {"error": "недостаточно рублёв"}
        else:
            connection.close()
            return {"error": "предмета с таким id нету тут ><"}
    else:
        connection.close()
        return {"error": "user not found"}


@app.route("/api/homes/<int:home_id>/garden/plant")
def plant(home_id):
    position = int(request.args["pos"])
    if not (position > 0 and position <= 3):
        return {"error": "wrong position"}
    seed = request.args["seed"]
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT * FROM Workspaces WHERE (id = ?) AND (owner_id = ?) AND (location = ?)", (home_id, user_to_dict(user)["id"], "home",))
        workspace = cursor.fetchone()
        if workspace:
            fields = json.loads(workspace[6])
            print(fields)
            if fields[0][str(position)] is None:
                item = item_in_inventory(user_to_dict(user)["inventory"], seed, "seed")
                if item:
                    inventory = user_to_dict(user)["inventory"]
                    for seed in inventory:
                        if seed == item:
                            old_seed = seed
                            seed["qty"] -= 1
                            if seed["qty"] <= 0:
                                inventory.remove(old_seed)
                    cursor.execute(
                        "UPDATE Users SET inventory = ? WHERE id = ?",
                        (json.dumps(inventory), user_to_dict(user)["id"])
                        )
                    fields[0][str(position)] = {"seed": item, "time": _time.time() + random.uniform(60, 80)}
                    cursor.execute("UPDATE Workspaces SET location_objects = ? WHERE id = ?", (json.dumps(fields), home_id))
                    connection.commit()
                    connection.close()
                    return {"me": user_to_dict(user), "location_objects": fields}
                else:
                    connection.close()
                    return {"error": "seeds not found"}
            else:
                connection.close()
                return {"error": "pos not free"}
        else:
            connection.close()
            return {"error": "workspace not found"}
    else:
        connection.close()
        return {"error": "user not found"}


@app.route("/api/homes/<int:home_id>/garden/harvest")
def harvest(home_id):
    position = request.args["pos"]
    token = request.args["token"]
    if int(position[0]) > 2 or int(position[0]) <= 0 or int(position[1]) > 3 or int(position[1]) <= 0:
        return {"error": "wrong position"}
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT * FROM Workspaces WHERE (id = ?) AND (owner_id = ?) AND (location = ?)", (home_id, user_to_dict(user)["id"], "home",))
        workspace = cursor.fetchone()
        fields = json.loads(workspace[5])
        if workspace:
            if fields[position[0] -1]["plants"][str(position[1])] is not None:
                if (_time.time() - fields[position[0] -1]["plants"][str(position[1])]["time"]) >= 0:
                    inventory = user_to_dict(user)["inventory"]
                    resource = fields[position[0] -1]["plants"][str(position[1])]["seeds"]["plant"]
                    fields[position[0] -1]["plants"][str(position[1])] = None
                    inventory = add_to_inventory(inventory, resource)
                    cursor.execute("UPDATE Users SET inventory = ? WHERE id = ?", 
                                (json.dumps(inventory), user_to_dict(user)["id"]))
                    cursor.execute("UPDATE Workspaces SET location_objects = ? WHERE id = ?", (json.dumps(fields), home_id))
                    connection.commit()
                    connection.close()
            else:
                return {"error": "пустоту собрать пытаешься, гений..."}
        else:
            return {"error": "this workspace isn't real"}
    else:
        return {"error": "user not found"}

@app.route("/api/workspaces/workspace/<int:workspace_id>/change_name")
def change_workspace_name(workspace_id):
    name = request.args["name"]
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Workspaces WHERE id = ?", (workspace_id,))
    workspace = cursor.fetchone()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if workspace and workspace_to_dict(workspace)["owner_id"] == user_to_dict(user)["id"]:
        cursor.execute("UPDATE Workspaces SET name = ? WHERE id = ?", (name, workspace_id,))
        cursor.execute("SELECT * FROM Workspaces WHERE owner_id = ?", (user[1],))
        workspaces = workspaces_to_list(cursor.fetchall())
        connection.commit()
        connection.close()
        return workspaces
    else:
        connection.close()
        return {"error": "вы не являетесь владельцем этой рабочей зоны."}
    


@app.route("/api/workspaces/workspace/<int:workspace_id>/interact/<int:slot>", methods=["GET"])
def interact_with(workspace_id, slot):
    slot -= 1
    item = request.args["with"]
    if not item:
        return {"error": "select an item"}
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user_to_dict(user)["stats"]["energy"] <= 0:
        return {"error": "Вы очень сильно устали и не можете добывать ресурсы дальше!\nВосстановите энергию, поев лесных ягод или поспав на кровати у себя дома."}
    if user:
        if not user_to_dict(user)["access"]["allowed"]:
            return {"error": "Your account is banned!\nReason: " + user_to_dict(user)["access"]["reason"]}
        inventory = user_to_dict(user)["inventory"]
        if item_in_inventory(inventory, item):
            item = item_in_inventory(inventory, item)
            cursor.execute("SELECT * FROM Workspaces WHERE (id = ?) AND (owner_id = ?)", (workspace_id, user_to_dict(user)["id"],))
            workspace = cursor.fetchone()
            print(workspace)
            if json.loads(workspace_to_dict(workspace)["location_objects"])[slot]["id"] in item["interact_w"]:
                if workspace:
                    if (_time.time() - user_to_dict(user)["extraction"]) >= 0:
                        resource = None
                        stats = user_to_dict(user)["stats"]
                        stats["energy"] -= 3
                        cursor.execute("UPDATE Users SET stats = ? WHERE token = ?", (json.dumps(stats), token,))
                        connection.commit()
                        location_objects = json.loads(workspace_to_dict(workspace)["location_objects"])
                        print(location_objects[slot]["hp"])
                        location_objects[slot]["hp"] -= item_in_inventory(inventory, item["id"])["stats"]["str"]
                        if random.random() < 0.5:
                            gold = json.loads(user[8])["gold"] + random.randint(1, 3)
                            wallet = {"gold": gold, "diamonds": json.loads(user[8])["diamonds"]}
                            cursor.execute("UPDATE Users SET wallet = ? WHERE token = ?", (json.dumps(wallet), token,))
                            connection.commit()
                        if location_objects[slot]["hp"] <= 0:
                            new_object = random.choice(game.location_objects)
                            while new_object["tag"] == location_objects[slot]["tag"]:
                                new_object = random.choice(game.location_objects)
                            location_objects[slot] = new_object
                            resource = game.resources[random.choice(json.loads(workspace_to_dict(workspace)["location_objects"])[slot]["resources"])]
                            #cursor.execute("UPDATE Users SET extraction_resources = ? WHERE id = ?", (json.dumps([resource]), user_to_dict(user)["id"],))
                            qty = random.randrange(2, 4)
                            i = 0
                            while i < qty:
                                inventory = add_to_inventory(inventory, resource)
                                i += 1
                            cursor.execute(
                                "UPDATE Users SET inventory = ? WHERE id = ?",
                                (json.dumps(inventory), user_to_dict(user)["id"])
                            )
                            connection.commit()
                            resource = [resource, qty]
                        cursor.execute("UPDATE Workspaces SET location_objects = ? WHERE (id = ?)", (json.dumps(location_objects), workspace_id))
                        connection.commit()
                        cooldown = random.uniform(0.5, 1)
                        cursor.execute("UPDATE Users SET extraction = ? WHERE token = ?", (_time.time() + cooldown, token,))
                        connection.commit()
                        connection.close()
                        return {"cooldown": cooldown + 0.05, "location_object": location_objects[slot], "resource": resource, "user": user_to_dict(user), "inventory": inventory, "stats": stats}, 200
                    else:
                        connection.close()
                        _cooldown = _time.time() - user_to_dict(user)['extraction']
                        return {"error": f"подожди ещё {_cooldown + 0.05} секунд, пожалуйста.", "cooldown": _cooldown}, 429
                else:
                    connection.close()
                    return {"error": "ты кажись уже не в рабочей зоне..."}, 404
            else:
                print("ну и чо за хуйня" + str(json.loads(workspace_to_dict(workspace)["location_objects"])[slot]))
                connection.close()
                right_tools = []
                for item in game.items:
                    if json.loads(workspace_to_dict(workspace)["location_objects"])[slot]["id"] in item["interact_w"]:
                        right_tools.append(item)
                return {"error": "wrong tool", "right_tools": right_tools}, 404
        else:
            connection.close()
            return {"error": "инфа устарела лол или у тебя читы", "description": "иди обновись блять и закрой всю хуйню безобразную..."}
    else:
        connection.close()
        return {"error": "user with this token not found x_x"}, 404




@app.route("/api/update_inventory")
def update_inventory():
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        connection.close()
        return user_to_dict(user)["inventory"]
    else:
        connection.close()
        return {"error": "user not found"}


def take_res(workspace_id, slot, token):
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT * FROM Workspaces WHERE id = ?", (workspace_id,))
        workspace = cursor.fetchone()
        if workspace and workspace_to_dict(workspace)["location_objects"][slot]["health"] <= 0:
            location_objects = workspace_to_dict(workspace)["location_objects"]
            location_objects[slot] = random.choice(game.location_objects)
            resource = random.choice(location_objects[slot]["resources"])
            inventory = add_to_inventory(user_to_dict(user)["inventory"], resource)
            cursor.execute("UPDATE Workspaces SET location_objects = ?, inventory = ? WHERE id = ? AND owner_id", (json.dumps(location_objects), 
                                                                                                      json.dumps(inventory), workspace_id,))
            connection.commit()
            connection.close()
            return {"res": resource}
        else:
            connection.close()
            return {"error": "ресурс ещё не добыт!"}
    else:
        connection.close()
        return {"error": "user not found"}


@app.route("/api/workspaces/create")
def create_new_workspace():
    token = request.args["token"]
    location_name = request.args["location"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        inventory = user_to_dict(user)["inventory"]
        log = None
        cobblestone = None
        for slot in inventory:
            if slot["tag"] == "Log" and slot["qty"] >= 100:
                slot["qty"] -= 100
                if slot["qty"] == 0:
                    pass
                log = slot
            elif slot["tag"] == "Cobblestone" and slot["qty"] >= 50:
                slot["qty"] -= 50
                if slot["qty"] == 0:
                    pass
                cobblestone = slot
            else:
                if log and cobblestone:
                    pass
                else:
                    return {"error": "недостаточно ресурсов для постройки дома."}
        create_workspace(user_to_dict(user)["id"])
        return {"success": "дом построен, иди нахуй теперь"}
    else:
        return {"error": "тебя не существует"}


@app.route("/api/me/change/nickname_color")
def change_nickname_color():
    color = request.args["color"]
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        if not user_to_dict(user)["access"]["allowed"]:
            return {"error": "Your account is banned!\nReason: " + user_to_dict(user)["access"]["reason"]}
        if json.loads(user[12])["active"]:
            cursor.execute("UPDATE Users SET nickname = ? WHERE token = ?", (json.dumps([json.loads(user[0])[0], color, json.loads(user[0])[2]]),
                                                                             token,))
            connection.commit()
            cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
            user = cursor.fetchone()
            connection.close()
            return user_to_dict(user)
        else:
            connection.close()
            return {"subscription_error": "для смены цвета никнейма необходимо приобрести подписку!", "link": "https://t.me/yumenoworx"}
    else:
        connection.close()
        return {"error": "user not found"}

@app.route("/api/me/change/nickname_effect")
def change_nickname_effect():
    try:
        effect_id = int(request.args["id"])
    except:
        return {"error": "unknown effect"}
    if not effect_id in [0, 1, 2, 3]:
        return {"error": "unknown effect"}
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        if not user_to_dict(user)["access"]["allowed"]:
            return {"error": "Your account is banned!\nReason: " + user_to_dict(user)["access"]["reason"]}
        if json.loads(user[12])["active"]:
            cursor.execute("UPDATE Users SET nickname = ? WHERE token = ?", (json.dumps([json.loads(user[0])[0], json.loads(user[0])[1], effect_id]),
                                                                             token,))
            connection.commit()
            cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
            user = cursor.fetchone()
            connection.close()
            return user_to_dict(user)
        else:
            connection.close()
            return {"subscription_error": "для смены эффекта никнейма необходимо приобрести подписку!", "link": "https://t.me/maidcode"}
    else:
        connection.close()
        return {"error": "user not found"}


@app.route("/api/me/change/password")
def change_password():
    token = request.args["token"]
    password = str(hashlib.pbkdf2_hmac("sha256", request.args["password"].encode("utf-8"), token.encode("utf-8"), 11111)).replace('b"', "").replace('"', "").replace("\\", "").replace("'", "")
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
            cursor.execute("UPDATE Users SET password = ? WHERE token = ?", (password, token,))
            connection.commit()
            cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
            user = cursor.fetchone()
            connection.close()
            return user_to_dict(user)
    else:
        connection.close()
        return {"error": "user not found"}

@app.route("/api/me/change/nickname")
def change_nickname():
    nickname = request.args["nickname"]
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        if not user_to_dict(user)["access"]["allowed"]:
            return {"error": "Your account is banned!\nReason: " + user_to_dict(user)["access"]["reason"]}
        if len(nickname) > 13:
            return {"error": f"сократите длину никнейма до 13 символов"}
        if len(nickname) < 2:
            return {"error": f"никнейм не может быть короче двух символов."}
        for symbol in nickname.lower():
            if symbol not in game.nickname_filter:
                return {"error": f"символ \"{symbol}\" не может использоваться в никнейме"}
        cursor.execute('SELECT nickname FROM users')
        nicknames = cursor.fetchall()
        for random_nickname in nicknames:
            print(random_nickname)
            if json.loads(random_nickname[0])[0].lower() == nickname.lower():
                return jsonify({"error": "this nickname is already taken"})
        if json.loads(user[12])["active"]:
            cursor.execute("UPDATE Users SET nickname = ? WHERE token = ?", (json.dumps([nickname, json.loads(user[0])[1], json.loads(user[0])[2]]),
                                                                             token,))
            connection.commit()
            cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
            user = cursor.fetchone()
            connection.close()
            return user_to_dict(user)
        else:
            connection.close()
            return {"subscription_error": "для смены цвета никнейма необходимо приобрести подписку!", "link": "https://t.me/yumenoworx"}
    else:
        connection.close()
        return {"error": "user not found"}

@app.route("/api/workspaces/my_own")
def get_my_workspaces():
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT * FROM Workspaces WHERE owner_id = ?", (user[1],))
        return workspaces_to_list(cursor.fetchall())
    else:
        return {"error": "user with this token not found"}, 404


@app.route("/auth/signup/yandex")
def yandex_auth():
    pass

@app.route("/api/world/assets")
def send_assets():
    return {"items": game.items, "location_objects": game.location_objects, "resources": game.resources}, 200


def item_in_inventory(inventory, item: int, item_type="tool"):
    for slot in inventory:
        item = int(item)
        print(slot)
        if item == slot["id"] and item_type == slot["type"]:
            return slot


@app.route("/api/workspaces/workspace/<int:workspace_id>/join_request", methods=["GET"])
def join_request(workspace_id):
    return not_avaliable()
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    cursor.execute("SELECT * FROM Workspaces WHERE id = ?", (workspace_id,))
    workspace = cursor.fetchone()
    if workspace and user[1] not in json.loads(workspace[2]):
        cursor.execute("UPDATE Workspaces SET join_requests = ? WHERE id = ?", (json.dumps(json.loads(workspace[3]).append(user[1]))))
        connection.commit()
    connection.close()




@app.route("/api/workspaces/create")
def create_workspace():
    return not_avaliable()
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users WHERE token = ?", (token,))
    user = cursor.fetchone()
    if user:
        cursor.execute("SELECT MAX(id) FROM Workspaces")
        id = cursor.fetchone() + 1
        cursor.execute("INSERT INTO Workspaces (id, owner_id, members, join_requests, location, location_objects,)", (id, user[1], user[1], json.dumps([]), "forest", json.dumps([random.choice(game.location_objects),
                                                                                                                                                                                  random.choice(game.location_objects),
                                                                                                                                                                                  random.choice(game.location_objects),
                                                                                                                                                                                  random.choice(game.location_objects),
                                                                                                                                                                                  random.choice(game.location_objects),
                                                                                                                                                                                  random.choice(game.location_objects),])))
        cursor.execute("SELECT * FROM Workspaces WHERE id = ?", (id,))
        workspace = cursor.fetchone()
        connection.commit()
        connection.close()
        return workspace_to_dict(workspace), 200
    else:
        connection.commit()
        connection.close()
        return {"error": "user not found"}, 404


def create_workspace(_id, workspace_type="Forest"):
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    user = True
    if user:
        if workspace_type == "Forest":
            cursor.execute("INSERT INTO Workspaces (name, owner_id, members, join_requests, location, location_objects) VALUES (?, ?, ?, ?, ?, ?)", ("Forest", _id, json.dumps([_id]), json.dumps([]), "forest", json.dumps([random.choice(game.location_objects), 
                                                                                                                                                                                                        random.choice(game.location_objects), 
                                                                                                                                                                                                        random.choice(game.location_objects), 
                                                                                                                                                                                                        random.choice(game.location_objects), 
                                                                                                                                                                                                        random.choice(game.location_objects), 
                                                                                                                                                                                                        random.choice(game.location_objects)])))
        elif workspace_type == "Home":
            cursor.execute("INSERT INTO Workspaces (name, owner_id, members, join_requests, location, location_objects) VALUES (?, ?, ?, ?, ?, ?)", ("Home", _id, json.dumps([_id]), json.dumps([]), "home", json.dumps([{"1": None, "2": None, "3": None}, {"1": None, "2": None, "3": None}])))
        ws_id = cursor.lastrowid
        connection.commit()
        cursor.execute("SELECT * FROM Workspaces WHERE id = ?", (ws_id,))
        workspace = cursor.fetchone()
        connection.close()
        print(workspace_to_dict(workspace))
        print(workspace_to_dict(workspace)["id"])
        return workspace_to_dict(workspace)["id"]
    else:
        connection.commit()
        connection.close()
        return {"error": "user not found"}, 404
        
        
@app.route("/api/me", methods=["GET"])
def me():
    token = request.args["token"]
    connection = sqlite3.connect('database.db')
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    cursor.execute("SELECT * FROM Workspaces WHERE owner_id = ?", (user[1],))
    workspaces = cursor.fetchall()
    connection.close()
    return {"me": user_to_dict(user), "workspaces": workspaces_to_list(workspaces)}


@app.route("/auth/login", methods=["GET"])
def login():
    print(request.args)
    if "email" in request.args and "password" in request.args:
        email = request.args["email"]
        connection = sqlite3.connect('database.db')
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
        print(user)
        connection.close()
        print(user)
        if user:
            password = str(hashlib.pbkdf2_hmac("sha256", request.args["password"].encode("utf-8"), user[4].encode("utf-8"), 11111)).replace('b"', "").replace('"', "").replace("\\", "").replace("'", "")
            print(password + " ?= " + user[3])
            if user[3] == password:
                if not user_to_dict(user)["access"]["allowed"]:
                    return {"error": "Your account is banned!\nReason: " + user_to_dict(user)["access"]["reason"]}
                return jsonify(user_to_dict(user)), 200
            else:
                return jsonify({"error": "wrong username or password"}), 404
        else:
            return jsonify({"error": "user not found"}), 404
    else:
        return jsonify({"error": "Enter nickname and password"}), 404


@app.route("/auth/signup", methods=["GET"])
def signup():
    nickname = request.args["nickname"]
    email = request.args["email"]
    token = token_generator(nickname, email)
    password = str(hashlib.pbkdf2_hmac("sha256", request.args["password"].encode("utf-8"), token.encode("utf-8"), 11111)).replace('b"', "").replace('"', "").replace("\\", "").replace("'", "")
    connection = sqlite3.connect("database.db")
    cursor = connection.cursor()
    try:
        cursor.execute('SELECT email FROM users WHERE email = ?', (email, ))
        if cursor.fetchone() is not None:
            return jsonify({"error": "account with this email already exists"})
        if len(nickname) > 13:
            return {"error": f"сократите длину никнейма до 13 символов"}
        if len(nickname) < 2:
            return {"error": f"никнейм не может быть короче двух символов."}
        for symbol in nickname.lower():
            if symbol not in game.nickname_filter:
                return {"error": f"символ \"{symbol}\" не может использоваться в никнейме"}
        cursor.execute('SELECT nickname FROM users')
        nicknames = cursor.fetchall()
        for random_nickname in nicknames:
            print(random_nickname)
            if json.loads(random_nickname[0])[0].lower() == nickname.lower():
                return jsonify({"error": "this nickname is already taken"})
        seeds = game.seeds[0]
        seeds["qty"] = 3
        cursor.execute('INSERT INTO Users (nickname, email, password, token, role, access, stats, wallet, inventory, extraction, extraction_resources, subscription, verified, status, profile, friends, fans) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (json.dumps([nickname, "ffffff", 0]), 
                                                                                                                                                           email, password, token, json.dumps({"name": "player", "type": None, "color_override": None}),
                                                                                                                                                           json.dumps({"allowed": True, "reason": None}), 
                                                                                                                                                           json.dumps({"hp": 100, "str": 0, "def": 0, "energy": 300}),
                                                                                                                                                           json.dumps({"gold": 0, "diamonds": 0}),
                                                                                                                                                           json.dumps([game.items[0], game.items[1], seeds]), 0, json.dumps([]), json.dumps({"active": False, "expire": -1}),
                                                                                                                                                           json.dumps({"status": False, "description": None}),
                                                                                                                                                           json.dumps({"type": "cheerful", "timer": 0}),
                                                                                                                                                           json.dumps({"motto": "there's no any motto", "description": "description."}),
                                                                                                                                                           json.dumps([]),
                                                                                                                                                           json.dumps([])))
        user_id = cursor.lastrowid
        connection.commit()
        create_workspace(user_id, "Forest")
        create_workspace(user_id, "Home")
    except Exception as exc:
        connection.close()
        print(traceback.format_exc())
        return {"error": traceback.format_exc()}
    cursor.execute("SELECT * FROM users WHERE token = ?", (token,))
    user = cursor.fetchone()
    connection.close()
    # convert to dict
    return jsonify(user_to_dict(user)), 200


def error(exc):
    return f"<html style=\"background-color: #222222\";>" \
           f"<footer style=\"font-family: Noto Sans Mono; color: red;\">{exc}</footer>" \
           f"</html>"


def answer(text):
    return f"<html style=\"background-color: #222222\";>" \
           f"<footer style=\"font-family: Noto Sans Mono; color: white;\">{text}</footer>" \
           f"</html>"


def table():
    connection = sqlite3.connect("database.db")
    cursor = connection.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS Users (nickname TEXT NOT NULL, 
                   id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL, 
                   password TEXT NOT NULL, token TEXT NOT NULL, role TEXT NOT NULL, 
                   access TEXT NOT NULL, stats TEXT NOT NULL, wallet TEXT NOT NULL, 
                   inventory TEXT NOT NULL,
                   extraction INTEGER, extraction_resources TEXT NOT NULL, 
                   subscription TEXT NOT NULL, verified TEXT NOT NULL, 
                   status TEXT NOT NULL,
                   profile TEXT NOT NULL,
                   friends TEXT NOT NULL,
                   fans TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS Workspaces (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, owner_id INTEGER, members TEXT NOT NULL, join_requests TEXT NOT NULL, location TEXT NOT NULL, location_objects TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS Chats (id TEXT NOT NULL, messages TEXT NOT NULL)''')
    connection.commit()
    connection.close()


def token_generator(nickname, email):
    return f'{random.randrange(100000, 999999)}:{random.randrange(100000, 999999)}.{random.randrange(100000, 999999)}'

def user_to_dict(user):
    return {"nickname": json.loads(user[0]), "id": user[1], "token": user[4], "role": json.loads(user[5]), 
            "access": json.loads(user[6]), "stats": json.loads(user[7]), "wallet": {"gold": format(json.loads(user[8])["gold"], ",").replace(",", " ")}, "inventory": json.loads(user[9]), 
            "extraction": user[10], "subscription": json.loads(user[12]), "verified": json.loads(user[13]), "status": json.loads(user[14]), 
            "profile": json.loads(user[15]), "friends": json.loads(user[16]), "fans": json.loads(user[17])}

def safe_user_to_dict(user):
    return {"nickname": json.loads(user[0]), "id": user[1], "role": json.loads(user[5]), 
            "access": json.loads(user[6]), "stats": json.loads(user[7]), "wallet": {"gold": format(json.loads(user[8])["gold"], ",").replace(",", " ")}, "inventory": json.loads(user[9]), 
            "extraction": user[10], "subscription": json.loads(user[12]), "verified": json.loads(user[13]), "status": json.loads(user[14]), 
            "profile": json.loads(user[15]), "friends": json.loads(user[16]), "fans": json.loads(user[17])}


def workspace_to_dict(workspace):
    return {"name": workspace[1], "id": workspace[0], "owner_id": workspace[2], "members": workspace[3], "join_requests": workspace[4],
            "location": workspace[5], "location_objects": workspace[6]}


def workspaces_to_list(workspaces):
    wss = []
    for workspace in workspaces:
        wss.append({"name": workspace[1], "id": workspace[0], "owner_id": workspace[2], "members": workspace[3], "join_requests": workspace[4], "location": workspace[5], "location_objects": workspace[6]})
    return wss


def not_avaliable(rq):
    return {"error": f"Эта функция временно недоступна."}


def add_to_inventory(inventory: list, item):
    for slot in inventory:
        slot = json.loads(slot) if not dict else slot
        if item["tag"] == slot["tag"]:
            print(f"предмет {item['tag']} добавлен в инвентарь в количестве {item['qty']} шт.ы")
            slot["qty"] += item["qty"]
            return inventory
    inventory.append(item)
    return inventory

table()
# thread = threading.Thread(target=timer)
# thread.start()

if __name__ == "__main__":
    from waitress import serve
    #serve(app, host="0.0.0.0", port=59901)
    app.run("0.0.0.0", "59901")

# CVDontHackMePls!!!
# https://www.digitalocean.com/community/tutorials/how-to-make-a-web-application-using-flask-in-python-3-ru
